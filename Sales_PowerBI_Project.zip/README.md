# Power BI Sales Dashboard Project

Sample project folder containing data and placeholders.
